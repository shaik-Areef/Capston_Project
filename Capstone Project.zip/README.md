step1. Install nodemodules 

### npm install

step2. Run db.json server in port 5000

### json-server db.json --port 5000

step3. Run the code 

### npm start

step4. Run the Testcases 

### npm run test 

step5. Run the commend for coverage for testcases

### npm run test -- -- coverage

### npm run test -- -- coverage --WatchAll=false




